import './App.css'
import Form from './components/Form/Form'
import Fruit from './components/Mesa 7/Fruit'

export default function App() {
  
  return (
    <>
      <Form />
      <Fruit/>
    </>
  )
}


